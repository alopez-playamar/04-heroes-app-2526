// Producción
export const environments = {
  baseUrl: 'http://produccion.iesplayamar.es/api'
}
