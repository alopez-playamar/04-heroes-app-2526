import { Component } from '@angular/core';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.html',
  styles: ``,
  standalone: false
})
export class LoginPageComponent {

}
