import { Component } from '@angular/core';

@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.html',
  styles: ``,
  standalone: false
})
export class RegisterPageComponent {

}
